export default function About() {
    return (
        <div className="innerPage aboutPage">
            
        </div>
    )
}