import ContactSocial from "../Components/ContactSocial";
import ContactText from "../Components/ContactText";

export default function Contact() {
    return (
        <div className="innerPage contactPage">
            <ContactText />
            <ContactSocial />
        </div>
    )
}