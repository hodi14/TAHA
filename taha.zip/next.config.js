module.exports = {
  reactStrictMode: true,
  basePath: ''
}
